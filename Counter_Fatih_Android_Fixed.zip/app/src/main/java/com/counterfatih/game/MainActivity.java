package com.counterfatih.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new GameView());
    }

    static class GameView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int ammo = 30, score = 0;
        private String status = "READY";
        private float playerX = 0;
        GameView(Activity a) { super(a); setFocusable(true); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(91,118,83));
            p.setColor(Color.rgb(118,111,91));
            c.drawRect(0,h*.62f,w,h,p);
            p.setColor(Color.rgb(80,91,69));
            c.drawRect(w*.12f,h*.25f,w*.28f,h*.62f,p);
            c.drawRect(w*.72f,h*.20f,w*.88f,h*.62f,p);
            p.setColor(Color.rgb(65,70,62));
            c.drawRect(w*.43f,h*.48f,w*.57f,h*.64f,p);
            p.setColor(Color.WHITE); p.setTextSize(26);
            c.drawText("COUNTER FATIH", 24, 34, p);
            c.drawText("HP: 100", 24, 66, p);
            c.drawText("AMMO: "+ammo+"    SCORE: "+score, 24, 98, p);
            // crosshair
            p.setStrokeWidth(3);
            c.drawLine(w/2-15,h/2,w/2-5,h/2,p);
            c.drawLine(w/2+5,h/2,w/2+15,h/2,p);
            c.drawLine(w/2,h/2-15,w/2,h/2-5,p);
            c.drawLine(w/2,h/2+5,w/2,h/2+15,p);
            // target dummy
            float tx=w*.62f+playerX;
            p.setColor(Color.rgb(170,48,42));
            c.drawCircle(tx,h*.45f,18,p);
            c.drawRect(tx-12,h*.47f,tx+12,h*.57f,p);
            p.setColor(Color.WHITE); p.setTextSize(20);
            c.drawText(status,w*.42f,h*.14f,p);
            // touch controls
            p.setColor(0xAA202020);
            c.drawCircle(72,h-72,48,p);
            c.drawCircle(w-78,h-76,52,p);
            p.setColor(Color.WHITE); p.setTextSize(18);
            c.drawText("MOVE",42,h-66,p);
            c.drawText("FIRE",w-103,h-69,p);
            p.setTextSize(15);
            c.drawText("Prototype • touch FIRE to shoot", w/2-130, h-18,p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                float w=getWidth(), h=getHeight(), x=e.getX(), y=e.getY();
                if (e.getAction()==MotionEvent.ACTION_DOWN && x>w*.72f && y>h*.62f) {
                    if (ammo>0) { ammo--; score++; status="SHOT!"; }
                    else status="OUT OF AMMO";
                } else if (x<w*.25f && y>h*.62f) {
                    playerX += (x<w*.12f ? -5 : 5);
                    if (playerX>80) playerX=-80;
                    if (playerX< -80) playerX=80;
                    status="MOVING";
                }
                invalidate();
                return true;
            }
            return true;
        }
    }
}
